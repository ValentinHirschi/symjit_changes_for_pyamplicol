import numbers

import numpy as np

from . import engine, pyengine


class Func:
    def __init__(self, compiler, eqs):
        self.compiler = compiler
        self.count_states = self.compiler.count_states
        self.count_params = self.compiler.count_params
        self.count_obs = self.compiler.count_obs
        self.f = self.compiler.fast_func()
        self.prepare_fmt(eqs)
        self.prepare_vecfmt(eqs)

    def prepare_fmt(self, eqs):
        if self.f is not None:
            if isinstance(eqs, list):
                self.fmt = lambda args: [self.f(*args)]
            elif isinstance(eqs, tuple):
                self.fmt = lambda args: (self.f(*args),)
            else:
                self.fmt = lambda args: self.f(*args)
        else:
            if isinstance(eqs, list):
                self.fmt = lambda obs: obs.tolist()
            elif isinstance(eqs, tuple):
                self.fmt = lambda obs: tuple(obs.tolist())
            else:
                self.fmt = lambda obs: obs[0]

    def prepare_vecfmt(self, eqs):
        if isinstance(eqs, list):
            self.vecfmt = lambda res: res
        elif isinstance(eqs, tuple):
            self.vecfmt = lambda res: tuple(res)
        else:
            self.vecfmt = lambda res: res[0]

    def __call__(self, *args):
        if len(args) > self.count_states:
            p = np.array(args[self.count_states :])
            self.compiler.params[:] = p

        if isinstance(args[0], numbers.Number):
            if self.f is not None:
                return self.fmt(args)

            u = np.asarray(args[: self.count_states])
            self.compiler.states[:] = u
            self.compiler.execute()
            return self.fmt(self.compiler.obs)
        elif isinstance(self.compiler, pyengine.PyCompiler):
            return self.call_vectorized(*args)
        else:
            return self.call_matrix(*args)

    def call_vectorized(self, *args):
        assert len(args) >= self.count_states
        shape = args[0].shape
        n = args[0].size
        h = max(self.count_states, self.count_obs)
        buf = np.zeros((h, n), dtype=np.float64)

        for i in range(self.count_states):
            assert args[i].shape == shape
            buf[i, :] = args[i].ravel()

        self.compiler.execute_vectorized(buf)

        res = []
        for i in range(self.count_obs):
            y = buf[i, :].reshape(shape)
            res.append(y)

        return self.vecfmt(res)

    def call_matrix(self, *args):
        assert len(args) >= self.count_states
        shape = args[0].shape

        with engine.Matrix() as states:
            for i in range(self.count_states):
                assert args[i].shape == shape
                states.add_row(args[i])

            res = []

            with engine.Matrix() as obs:
                for i in range(self.count_obs):
                    X = np.zeros(shape, dtype=np.float64)
                    res.append(X)
                    obs.add_row(X)

                self.compiler.execute_matrix(states, obs)

        return self.vecfmt(res)

    def dump(self, name: str, what: str="scalar"):
        self.compiler.dump(name, what=what)

    def dumps(self, what: str="scalar"):
        return self.compiler.dumps(what=what)

    def measure(self, what: str="ker-scalar-size"):
        return self.compiler.measure(what=what)

    def fast_func(self):
        return self.f

    def execute_vectorized(self, buf):
        self.compiler.execute_vectorized(buf)

    def apply(self, y, p=None):
        y = np.asarray(y, dtype=np.float64)
        self.compiler.states[:] = y

        if p is not None:
            p = np.asarray(p, dtype=np.float64)
            self.compiler.params[:] = p

        self.compiler.execute()
        return self.compiler.obs

    def callable_quad(self, use_fast=True):
        return self.compiler.callable_quad(use_fast=use_fast)

    def callable_filter(self):
        return self.compiler.callable_filter()

    def save(self, file):
        self.compiler.save(file)


class FuncComplex:
    def __init__(self, compiler, eqs):
        self.compiler = compiler
        self.count_states = self.compiler.count_states
        self.count_params = self.compiler.count_params
        self.count_obs = self.compiler.count_obs
        self.prepare_fmt(eqs)
        self.prepare_vecfmt(eqs)

    def prepare_fmt(self, eqs):
        if isinstance(eqs, list):
            self.fmt = lambda obs: np.frombuffer(obs, dtype=np.complex128).tolist()
        elif isinstance(eqs, tuple):
            self.fmt = lambda obs: tuple(
                np.frombuffer(obs, dtype=np.complex128).tolist()
            )
        else:
            self.fmt = lambda obs: obs[0] + obs[1] * 1j

    def prepare_vecfmt(self, eqs):
        if isinstance(eqs, list):
            self.vecfmt = lambda res: res
        elif isinstance(eqs, tuple):
            self.vecfmt = lambda res: tuple(res)
        else:
            self.vecfmt = lambda res: res[0]

    def __call__(self, *args):
        if isinstance(args[0], numbers.Number):
            u = np.frombuffer(
                np.asarray(args, dtype=np.complex128),
                dtype=np.float64,
            )
            self.compiler.params[: self.count_params] = u[self.count_states :]
            self.compiler.states[:] = u[: self.count_states]
            self.compiler.execute()
            return self.fmt(self.compiler.obs)
        else:
            return self.call_matrix(*args)

    def call_matrix(self, *args):
        if len(args) > self.count_states // 2:
            p = np.frombuffer(
                np.asarray(args[self.count_states // 2 :], dtype=np.complex128),
                dtype=np.float64,
            )
            self.compiler.params[:] = p

        shape = args[0].shape

        with engine.Matrix() as states:
            for i in range(self.count_states // 2):
                assert args[i].shape == shape
                v = np.ascontiguousarray(args[i], dtype=np.complex128)
                states.add_row(v.real)
                states.add_row(v.imag)

            res = []

            with engine.Matrix() as obs:
                AB = []

                for i in range(self.count_obs // 2):
                    a = np.empty(shape, dtype=np.float64)
                    b = np.empty(shape, dtype=np.float64)
                    obs.add_row(a)
                    obs.add_row(b)
                    AB.append((a, b))

                self.compiler.execute_matrix(states, obs)

                for a, b in AB:
                    z = np.empty(shape, dtype=np.complex128)
                    z.real = a
                    z.imag = b
                    res.append(z)

        return self.vecfmt(res)

    def dump(self, name: str, what: str="scalar"):
        self.compiler.dump(name, what=what)

    def dumps(self, what: str="scalar") -> str:
        return self.compiler.dumps(what=what)

    def measure(self, what: str="ker-scalar-size") -> int:
        return self.compiler.measure(what)

    def fast_func(self):
        return None

    def execute_vectorized(self, buf):
        if buf.dtype == np.complex128:
            self.compiler.execute_vectorized(buf)
        else:
            print("complex `execute_vectorized` expects a complex array as input.")


    def apply(self, y, p=None):
        pass

    def callable_quad(self, use_fast: bool=True):
        pass

    def callable_filter(self):
        pass

    def save(self, file: str):
        self.compiler.save(file)


############################################################################


class SymbolicaFunc:
    def __init__(self, model, dtype="float64", **args):
        self.model = model
        self.args = args
        self.samples = None
        self.is_complex = dtype == "complex128"

        if model is None:
            self.compiler = None
            self.complex_compiler = None
            self.args = {}
            return

        if dtype == "complex128":
            self.compile_complex()
            self.compiler = None
        else:
            self.compile_real()
            self.complex_compiler = None

    def compile_real(self):
        compiler = engine.RustyCompiler(self.model, dtype="float64", **self.args)
        self.compiler = compiler

    def compile_complex(self):
        compiler = engine.RustyCompiler(self.model, dtype="complex128", **self.args)
        self.complex_compiler = compiler

    def evaluate(self, inputs):
        if self.compiler is None:
            self.compile_real()

        inputs = np.asarray(inputs)
        c = self.compiler

        assert inputs.shape[1] == c.count_params

        outs = np.zeros((inputs.shape[0], c.count_obs), dtype=np.float64)

        args = np.ascontiguousarray(inputs[:, : c.count_params].real, dtype=np.float64)
        c.evaluate_matrix(args, outs)
        return outs

    def evaluate_complex(self, inputs):
        if self.complex_compiler is None:
            self.compile_complex()

        inputs = np.asarray(inputs)
        c = self.complex_compiler

        assert inputs.shape[1] == c.count_params // 2

        outs = np.zeros((inputs.shape[0], c.count_obs // 2), dtype=np.complex128)

        args = np.ascontiguousarray(inputs, dtype=np.complex128)
        c.evaluate_matrix(args, outs, 2)
        return outs

    def dump(self, name, what="scalar", dtype="complex128"):
        if dtype == "complex128" and self.complex_compiler is not None:
            return self.complex_compiler.dump(name, what=what)
        elif self.compiler is not None:
            return self.compiler.dump(name, what=what)

    def dumps(self, what="scalar", dtype="complex128"):
        if dtype == "complex128" and self.complex_compiler is not None:
            return self.complex_compiler.dumps(what=what)
        elif self.compiler is not None:
            return self.compiler.dumps(what=what)

    def measure(self, what: int="ker-scalar-size") -> int:
        if self.is_complex:
            return self.complex_compiler.measure(what)
        else:
            return self.compiler.measure(what)

    def save(self, file, dtype="complex128"):
        if dtype == "complex128":
            self.compile_complex()
            self.complex_compiler.save(file)
        else:
            self.compile_real()
            self.compiler.save(file)

    def __call__(self, *args):
        if self.is_complex:
            return self.evaluate_complex(np.asarray([args], dtype=np.complex128))
        else:
            return self.evaluate(np.asarray([args], dtype=np.float64))
